/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'blackout-black': '#000000',
        'neuro-yellow': '#FFE900',
        'asphalt-gray': '#4A4A4A',
        'toxic-cyan': '#00FEFE',
        'blood-red': '#FF0000',
      },
      fontFamily: {
        'trench': ['Trench 100', 'sans-serif'],
        'space-grotesk': ['Space Grotesk', 'sans-serif'],
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
}
